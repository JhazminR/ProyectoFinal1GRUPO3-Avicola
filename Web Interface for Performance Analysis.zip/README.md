
  # Web Interface for Performance Analysis

  This is a code bundle for Web Interface for Performance Analysis. The original project is available at https://www.figma.com/design/M6dQlyRWA5YmGWTzWqnuAB/Web-Interface-for-Performance-Analysis.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  