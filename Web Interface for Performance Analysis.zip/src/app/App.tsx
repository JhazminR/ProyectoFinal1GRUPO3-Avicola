import { useState } from "react";
import { LoginScreen } from "./components/LoginScreen";
import { Sidebar, type Screen } from "./components/Sidebar";
import { TopBar } from "./components/TopBar";
import { Dashboard } from "./components/Dashboard";
import { WorkersScreen } from "./components/WorkersScreen";
import { AreasScreen } from "./components/AreasScreen";
import { ActivitiesScreen } from "./components/ActivitiesScreen";
import { ReportsScreen } from "./components/ReportsScreen";
import { KPIsScreen } from "./components/KPIsScreen";
import { UsersScreen } from "./components/UsersScreen";

/* MARKER-MAKE-KIT-INVOKED */

const SCREEN_META: Record<Screen, { title: string; subtitle: string }> = {
  dashboard: { title: "Dashboard", subtitle: "Resumen general del sistema — Junio 2026" },
  workers: { title: "Gestión de Trabajadores", subtitle: "Administración del personal de producción" },
  areas: { title: "Áreas de Producción", subtitle: "Gestión y monitoreo de áreas productivas" },
  activities: { title: "Registro de Actividades", subtitle: "Ingreso de actividades laborales diarias" },
  reports: { title: "Reportes de Rendimiento", subtitle: "Análisis y exportación de informes de gestión" },
  kpis: { title: "Indicadores de Productividad", subtitle: "KPIs y métricas operativas del sistema" },
  users: { title: "Gestión de Usuarios", subtitle: "Administración de accesos y permisos del sistema" },
};

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [screen, setScreen] = useState<Screen>("dashboard");

  if (!loggedIn) {
    return <LoginScreen onLogin={() => setLoggedIn(true)} />;
  }

  const meta = SCREEN_META[screen];

  return (
    <div className="flex h-screen w-full overflow-hidden" style={{ background: "#f0f2f5" }}>
      <Sidebar current={screen} onNavigate={setScreen} onLogout={() => setLoggedIn(false)} />
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <TopBar title={meta.title} subtitle={meta.subtitle} />
        <main className="flex-1 overflow-hidden" style={{ background: "#f0f2f5" }}>
          {screen === "dashboard" && <Dashboard />}
          {screen === "workers" && <WorkersScreen />}
          {screen === "areas" && <AreasScreen />}
          {screen === "activities" && <ActivitiesScreen />}
          {screen === "reports" && <ReportsScreen />}
          {screen === "kpis" && <KPIsScreen />}
          {screen === "users" && <UsersScreen />}
        </main>
      </div>
    </div>
  );
}
