import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from "recharts";
import { Users, ClipboardCheck, MapPin, TrendingUp, ArrowUpRight, ArrowDownRight } from "lucide-react";

const barData = [
  { area: "Incubación", rendimiento: 92, meta: 90 },
  { area: "Crianza", rendimiento: 78, meta: 85 },
  { area: "Engorde", rendimiento: 88, meta: 85 },
  { area: "Beneficio", rendimiento: 95, meta: 90 },
  { area: "Empaque", rendimiento: 73, meta: 80 },
  { area: "Almacén", rendimiento: 84, meta: 85 },
];

const pieData = [
  { name: "Completadas", value: 68, color: "#2E8B57" },
  { name: "En progreso", value: 21, color: "#1E3A5F" },
  { name: "Pendientes", value: 11, color: "#e67e22" },
];

const recentActivities = [
  { id: "ACT-001", worker: "Carlos Mamani", area: "Incubación", activity: "Control de temperatura", hours: 8, date: "17/06/2026", status: "Completado" },
  { id: "ACT-002", worker: "Rosa Quispe", area: "Crianza", activity: "Alimentación lote A", hours: 7.5, date: "17/06/2026", status: "Completado" },
  { id: "ACT-003", worker: "Pedro Vargas", area: "Beneficio", activity: "Supervisión línea de corte", hours: 6, date: "16/06/2026", status: "Completado" },
  { id: "ACT-004", worker: "Ana Torres", area: "Empaque", activity: "Clasificación y etiquetado", hours: 8, date: "16/06/2026", status: "En progreso" },
  { id: "ACT-005", worker: "Luis Huanca", area: "Almacén", activity: "Control de inventario frío", hours: 4, date: "15/06/2026", status: "Pendiente" },
];

const kpiCards = [
  { label: "Total Trabajadores", value: "148", change: "+4", up: true, icon: Users, color: "#1E3A5F", bg: "rgba(30,58,95,0.08)" },
  { label: "Actividades Registradas", value: "1,243", change: "+87", up: true, icon: ClipboardCheck, color: "#2E8B57", bg: "rgba(46,139,87,0.08)" },
  { label: "Áreas de Producción", value: "6", change: "0", up: true, icon: MapPin, color: "#3498db", bg: "rgba(52,152,219,0.08)" },
  { label: "Productividad Promedio", value: "84.7%", change: "-1.2%", up: false, icon: TrendingUp, color: "#e67e22", bg: "rgba(230,126,34,0.08)" },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="rounded-lg p-3 shadow-lg" style={{ background: "#1E3A5F", border: "none", minWidth: "140px" }}>
        <p className="text-white mb-1" style={{ fontSize: "0.75rem", fontWeight: 600 }}>{label}</p>
        {payload.map((p: any) => (
          <p key={p.name} style={{ color: p.name === "rendimiento" ? "#4ade80" : "#93c5fd", fontSize: "0.72rem" }}>
            {p.name === "rendimiento" ? "Rendimiento" : "Meta"}: {p.value}%
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export function Dashboard() {
  return (
    <div className="p-6 space-y-6 overflow-y-auto h-full">
      {/* KPI Cards */}
      <div className="grid grid-cols-4 gap-4">
        {kpiCards.map(({ label, value, change, up, icon: Icon, color, bg }) => (
          <div key={label} className="rounded-xl p-4 shadow-sm" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: bg }}>
                <Icon className="w-5 h-5" style={{ color }} />
              </div>
              <span
                className="flex items-center gap-1 px-2 py-0.5 rounded-full"
                style={{
                  background: up ? "rgba(46,139,87,0.1)" : "rgba(192,57,43,0.1)",
                  color: up ? "#2E8B57" : "#c0392b",
                  fontSize: "0.72rem",
                  fontWeight: 500
                }}
              >
                {up ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                {change}
              </span>
            </div>
            <div style={{ color: "#1a2332", fontSize: "1.4rem", fontWeight: 700, lineHeight: 1 }}>{value}</div>
            <div style={{ color: "#6b7a8d", fontSize: "0.75rem", marginTop: "4px" }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-3 gap-4">
        {/* Bar chart */}
        <div className="col-span-2 rounded-xl p-5 shadow-sm" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 style={{ color: "#1E3A5F", fontSize: "0.9rem", fontWeight: 600 }}>Rendimiento por Área</h3>
              <p style={{ color: "#6b7a8d", fontSize: "0.75rem" }}>Comparativo real vs meta — Junio 2026</p>
            </div>
            <div className="flex gap-3">
              <span className="flex items-center gap-1.5" style={{ fontSize: "0.72rem", color: "#6b7a8d" }}>
                <span className="w-2.5 h-2.5 rounded-sm inline-block" style={{ background: "#1E3A5F" }} />Rendimiento
              </span>
              <span className="flex items-center gap-1.5" style={{ fontSize: "0.72rem", color: "#6b7a8d" }}>
                <span className="w-2.5 h-2.5 rounded-sm inline-block" style={{ background: "#2E8B57" }} />Meta
              </span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={barData} barGap={4}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(30,58,95,0.07)" vertical={false} />
              <XAxis dataKey="area" tick={{ fontSize: 11, fill: "#6b7a8d" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#6b7a8d" }} axisLine={false} tickLine={false} domain={[60, 100]} />
              <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(30,58,95,0.04)" }} />
              <Bar dataKey="rendimiento" fill="#1E3A5F" radius={[4, 4, 0, 0]} barSize={18} />
              <Bar dataKey="meta" fill="#2E8B57" radius={[4, 4, 0, 0]} barSize={18} opacity={0.7} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Pie chart */}
        <div className="rounded-xl p-5 shadow-sm" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
          <div className="mb-4">
            <h3 style={{ color: "#1E3A5F", fontSize: "0.9rem", fontWeight: 600 }}>Cumplimiento de Actividades</h3>
            <p style={{ color: "#6b7a8d", fontSize: "0.75rem" }}>Distribución del periodo actual</p>
          </div>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={3} dataKey="value">
                {pieData.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(v) => `${v}%`} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-2">
            {pieData.map(({ name, value, color }) => (
              <div key={name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: color }} />
                  <span style={{ color: "#6b7a8d", fontSize: "0.75rem" }}>{name}</span>
                </div>
                <span style={{ color: "#1a2332", fontSize: "0.8rem", fontWeight: 600 }}>{value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent activities table */}
      <div className="rounded-xl shadow-sm overflow-hidden" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
        <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: "1px solid rgba(30,58,95,0.07)" }}>
          <div>
            <h3 style={{ color: "#1E3A5F", fontSize: "0.9rem", fontWeight: 600 }}>Actividades Recientes</h3>
            <p style={{ color: "#6b7a8d", fontSize: "0.75rem" }}>Últimos registros del sistema</p>
          </div>
          <button className="px-3 py-1.5 rounded-lg" style={{ background: "#f3f4f6", color: "#1E3A5F", fontSize: "0.78rem", fontWeight: 500 }}>
            Ver todas
          </button>
        </div>
        <table className="w-full">
          <thead>
            <tr style={{ background: "#f8f9fb" }}>
              {["ID", "Trabajador", "Área", "Actividad", "Horas", "Fecha", "Estado"].map(h => (
                <th key={h} className="px-5 py-2.5 text-left" style={{ color: "#6b7a8d", fontSize: "0.72rem", fontWeight: 600, letterSpacing: "0.04em" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {recentActivities.map((act, i) => (
              <tr key={act.id} style={{ borderTop: "1px solid rgba(30,58,95,0.05)", background: i % 2 === 0 ? "#fff" : "#fafbfc" }}>
                <td className="px-5 py-3" style={{ color: "#1E3A5F", fontSize: "0.78rem", fontWeight: 600 }}>{act.id}</td>
                <td className="px-5 py-3" style={{ color: "#1a2332", fontSize: "0.8rem" }}>{act.worker}</td>
                <td className="px-5 py-3" style={{ color: "#6b7a8d", fontSize: "0.78rem" }}>{act.area}</td>
                <td className="px-5 py-3" style={{ color: "#374151", fontSize: "0.78rem" }}>{act.activity}</td>
                <td className="px-5 py-3" style={{ color: "#374151", fontSize: "0.78rem" }}>{act.hours}h</td>
                <td className="px-5 py-3" style={{ color: "#6b7a8d", fontSize: "0.78rem" }}>{act.date}</td>
                <td className="px-5 py-3">
                  <span className="px-2.5 py-1 rounded-full" style={{
                    fontSize: "0.7rem",
                    fontWeight: 600,
                    background: act.status === "Completado" ? "rgba(46,139,87,0.1)" : act.status === "En progreso" ? "rgba(30,58,95,0.1)" : "rgba(230,126,34,0.1)",
                    color: act.status === "Completado" ? "#2E8B57" : act.status === "En progreso" ? "#1E3A5F" : "#e67e22"
                  }}>{act.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
