import { Bell, Search, ChevronDown } from "lucide-react";

interface TopBarProps {
  title: string;
  subtitle?: string;
}

export function TopBar({ title, subtitle }: TopBarProps) {
  return (
    <header
      className="flex items-center justify-between px-6 py-3 flex-shrink-0"
      style={{
        background: "#ffffff",
        borderBottom: "1px solid rgba(30,58,95,0.1)",
        height: "56px"
      }}
    >
      <div>
        <h1 style={{ color: "#1E3A5F", fontSize: "1rem", fontWeight: 600, lineHeight: 1.2 }}>{title}</h1>
        {subtitle && <p style={{ color: "#6b7a8d", fontSize: "0.75rem", marginTop: "1px" }}>{subtitle}</p>}
      </div>
      <div className="flex items-center gap-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "#9ca3af" }} />
          <input
            placeholder="Buscar..."
            className="pl-9 pr-4 py-1.5 rounded-lg border outline-none"
            style={{
              borderColor: "#e5e7eb",
              background: "#f9fafb",
              fontSize: "0.8rem",
              width: "180px",
              color: "#374151"
            }}
          />
        </div>
        <button className="relative p-2 rounded-lg" style={{ background: "#f3f4f6" }}>
          <Bell className="w-4 h-4" style={{ color: "#6b7a8d" }} />
          <span className="absolute top-1 right-1 w-2 h-2 rounded-full" style={{ background: "#2E8B57" }} />
        </button>
        <div className="flex items-center gap-2 cursor-pointer px-2 py-1 rounded-lg" style={{ background: "#f3f4f6" }}>
          <div className="w-6 h-6 rounded-full flex items-center justify-center" style={{ background: "#1E3A5F" }}>
            <span className="text-white" style={{ fontSize: "0.6rem", fontWeight: 700 }}>JR</span>
          </div>
          <span style={{ color: "#374151", fontSize: "0.8rem" }}>Juan Rodríguez</span>
          <ChevronDown className="w-3 h-3" style={{ color: "#9ca3af" }} />
        </div>
      </div>
    </header>
  );
}
