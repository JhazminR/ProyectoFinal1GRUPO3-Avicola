import { useState } from "react";
import { Eye, EyeOff, Feather } from "lucide-react";

interface LoginScreenProps {
  onLogin: () => void;
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !pass) { setError("Ingrese usuario y contraseña."); return; }
    setError("");
    setLoading(true);
    setTimeout(() => { setLoading(false); onLogin(); }, 900);
  };

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center"
      style={{ background: "linear-gradient(135deg, #152a45 0%, #1E3A5F 55%, #246944 100%)" }}
    >
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5" style={{
        backgroundImage: "radial-gradient(circle at 25% 25%, white 1px, transparent 1px), radial-gradient(circle at 75% 75%, white 1px, transparent 1px)",
        backgroundSize: "50px 50px"
      }} />

      <div className="relative w-full max-w-md mx-4">
        {/* Card */}
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          {/* Header strip */}
          <div style={{ background: "linear-gradient(90deg, #1E3A5F 0%, #243f6b 100%)" }} className="px-8 py-7 text-center">
            {/* Logo */}
            <div className="flex items-center justify-center gap-3 mb-3">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: "#2E8B57" }}>
                <Feather className="w-7 h-7 text-white" />
              </div>
              <div className="text-left">
                <div className="text-white font-bold tracking-wide" style={{ fontSize: "1.1rem" }}>AVÍCOLA ANDINA</div>
                <div className="text-xs tracking-widest" style={{ color: "#a0b4c8" }}>GRUPO EMPRESARIAL</div>
              </div>
            </div>
            <div className="mt-2" style={{ color: "#cbd9e8", fontSize: "0.78rem", letterSpacing: "0.05em" }}>
              SISTEMA DE ANÁLISIS DE RENDIMIENTO LABORAL
            </div>
          </div>

          {/* Form */}
          <div className="px-8 py-8">
            <h2 className="text-center mb-1" style={{ color: "#1E3A5F", fontSize: "1.1rem" }}>Iniciar Sesión</h2>
            <p className="text-center mb-6" style={{ color: "#6b7a8d", fontSize: "0.82rem" }}>Ingrese sus credenciales de acceso</p>

            {error && (
              <div className="mb-4 px-4 py-2 rounded-lg text-sm" style={{ background: "#fef2f2", color: "#c0392b", border: "1px solid #fecaca" }}>
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block mb-1.5" style={{ color: "#374151", fontSize: "0.82rem", fontWeight: 500 }}>
                  Usuario
                </label>
                <input
                  type="text"
                  value={user}
                  onChange={e => setUser(e.target.value)}
                  placeholder="usuario@avicola.com"
                  className="w-full px-4 py-2.5 rounded-lg border outline-none transition-all"
                  style={{
                    borderColor: "#d1d5db",
                    background: "#f9fafb",
                    fontSize: "0.88rem",
                    color: "#1a2332"
                  }}
                  onFocus={e => { e.currentTarget.style.borderColor = "#1E3A5F"; e.currentTarget.style.boxShadow = "0 0 0 3px rgba(30,58,95,0.1)"; }}
                  onBlur={e => { e.currentTarget.style.borderColor = "#d1d5db"; e.currentTarget.style.boxShadow = "none"; }}
                />
              </div>

              <div>
                <label className="block mb-1.5" style={{ color: "#374151", fontSize: "0.82rem", fontWeight: 500 }}>
                  Contraseña
                </label>
                <div className="relative">
                  <input
                    type={showPass ? "text" : "password"}
                    value={pass}
                    onChange={e => setPass(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-4 py-2.5 pr-10 rounded-lg border outline-none transition-all"
                    style={{
                      borderColor: "#d1d5db",
                      background: "#f9fafb",
                      fontSize: "0.88rem",
                      color: "#1a2332"
                    }}
                    onFocus={e => { e.currentTarget.style.borderColor = "#1E3A5F"; e.currentTarget.style.boxShadow = "0 0 0 3px rgba(30,58,95,0.1)"; }}
                    onBlur={e => { e.currentTarget.style.borderColor = "#d1d5db"; e.currentTarget.style.boxShadow = "none"; }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass(!showPass)}
                    className="absolute right-3 top-1/2 -translate-y-1/2"
                    style={{ color: "#9ca3af" }}
                  >
                    {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between" style={{ marginTop: "4px" }}>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" className="w-3.5 h-3.5 rounded" style={{ accentColor: "#1E3A5F" }} />
                  <span style={{ color: "#6b7a8d", fontSize: "0.8rem" }}>Recordar sesión</span>
                </label>
                <span className="cursor-pointer" style={{ color: "#2E8B57", fontSize: "0.8rem" }}>¿Olvidó su contraseña?</span>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 rounded-lg font-medium text-white transition-all mt-2"
                style={{
                  background: loading ? "#6b7a8d" : "linear-gradient(90deg, #1E3A5F 0%, #243f6b 100%)",
                  fontSize: "0.9rem",
                  cursor: loading ? "not-allowed" : "pointer",
                  boxShadow: "0 4px 12px rgba(30,58,95,0.3)"
                }}
              >
                {loading ? "Verificando..." : "Iniciar Sesión"}
              </button>
            </form>
          </div>

          <div className="px-8 pb-6 text-center" style={{ borderTop: "1px solid #f3f4f6" }}>
            <p className="mt-4" style={{ color: "#9ca3af", fontSize: "0.75rem" }}>
              v2.4.1 — Avícola Andina S.A.C. © 2026
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
