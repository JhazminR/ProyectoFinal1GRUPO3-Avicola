import { useState } from "react";
import { Plus, Edit2, Trash2, Shield, ShieldCheck, Eye, EyeOff } from "lucide-react";

const initialUsers = [
  { id: "USR-001", name: "Juan Carlos Rodríguez Pérez", email: "jrodriguez@avicola.com", role: "Administrador", area: "Gerencia General", status: "Activo", lastLogin: "17/06/2026 08:32" },
  { id: "USR-002", name: "Silvia Mamani Chura", email: "smamani@avicola.com", role: "Supervisor", area: "Crianza", status: "Activo", lastLogin: "17/06/2026 07:15" },
  { id: "USR-003", name: "Marco Antonio Quispe Caro", email: "mquispe@avicola.com", role: "Supervisor", area: "Incubación", status: "Activo", lastLogin: "16/06/2026 14:50" },
  { id: "USR-004", name: "Patricia Torres Ayala", email: "ptorres@avicola.com", role: "Supervisor", area: "Beneficio", status: "Activo", lastLogin: "17/06/2026 06:58" },
  { id: "USR-005", name: "Roberto Vargas Llanos", email: "rvargas@avicola.com", role: "Operador", area: "Engorde", status: "Activo", lastLogin: "15/06/2026 11:22" },
  { id: "USR-006", name: "Carmen Flores Condori", email: "cflores@avicola.com", role: "Operador", area: "Empaque", status: "Inactivo", lastLogin: "10/06/2026 09:44" },
];

const PERMISSIONS: Record<string, string[]> = {
  "Administrador": ["Ver Dashboard","Gestionar Trabajadores","Gestionar Áreas","Registrar Actividades","Ver Reportes","Ver KPIs","Gestionar Usuarios","Exportar Datos","Configurar Sistema"],
  "Supervisor": ["Ver Dashboard","Gestionar Trabajadores","Registrar Actividades","Ver Reportes","Ver KPIs"],
  "Operador": ["Registrar Actividades","Ver Dashboard"],
};

export function UsersScreen() {
  const [users, setUsers] = useState(initialUsers);
  const [selected, setSelected] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ id: "", name: "", email: "", role: "Operador", area: "", status: "Activo" });

  const selectedUser = users.find(u => u.id === selected);

  return (
    <div className="p-6 overflow-y-auto h-full">
      <div className="grid grid-cols-3 gap-5">
        {/* Users table */}
        <div className="col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <p style={{ color: "#6b7a8d", fontSize: "0.8rem" }}>{users.length} usuarios en el sistema</p>
            <button
              onClick={() => setShowModal(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-white"
              style={{ background: "linear-gradient(90deg, #1E3A5F, #243f6b)", fontSize: "0.82rem" }}
            >
              <Plus className="w-4 h-4" /> Nuevo Usuario
            </button>
          </div>

          {/* Roles summary */}
          <div className="grid grid-cols-3 gap-3">
            {[
              { role: "Administrador", count: users.filter(u => u.role === "Administrador").length, color: "#1E3A5F", bg: "rgba(30,58,95,0.08)" },
              { role: "Supervisor", count: users.filter(u => u.role === "Supervisor").length, color: "#2E8B57", bg: "rgba(46,139,87,0.08)" },
              { role: "Operador", count: users.filter(u => u.role === "Operador").length, color: "#e67e22", bg: "rgba(230,126,34,0.08)" },
            ].map(({ role, count, color, bg }) => (
              <div key={role} className="rounded-lg px-4 py-3 flex items-center gap-3" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
                <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: bg }}>
                  <Shield className="w-4.5 h-4.5" style={{ color }} />
                </div>
                <div>
                  <div style={{ color: "#1a2332", fontSize: "1.1rem", fontWeight: 700 }}>{count}</div>
                  <div style={{ color: "#6b7a8d", fontSize: "0.72rem" }}>{role}s</div>
                </div>
              </div>
            ))}
          </div>

          {/* Table */}
          <div className="rounded-xl shadow-sm overflow-hidden" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
            <table className="w-full">
              <thead>
                <tr style={{ background: "#f8f9fb" }}>
                  {["Usuario","Email","Rol","Área","Estado","Último acceso",""].map(h => (
                    <th key={h} className="px-4 py-3 text-left" style={{ color: "#6b7a8d", fontSize: "0.7rem", fontWeight: 600, letterSpacing: "0.05em" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {users.map((u, i) => {
                  const roleColors: Record<string, { bg: string; text: string }> = {
                    "Administrador": { bg: "rgba(30,58,95,0.1)", text: "#1E3A5F" },
                    "Supervisor": { bg: "rgba(46,139,87,0.1)", text: "#2E8B57" },
                    "Operador": { bg: "rgba(230,126,34,0.1)", text: "#e67e22" },
                  };
                  const rc = roleColors[u.role] ?? { bg: "#f3f4f6", text: "#374151" };
                  return (
                    <tr
                      key={u.id}
                      onClick={() => setSelected(selected === u.id ? null : u.id)}
                      className="cursor-pointer"
                      style={{
                        borderTop: "1px solid rgba(30,58,95,0.05)",
                        background: selected === u.id ? "rgba(30,58,95,0.04)" : i % 2 === 0 ? "#fff" : "#fafbfc"
                      }}
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: "#1E3A5F" }}>
                            <span className="text-white" style={{ fontSize: "0.6rem", fontWeight: 700 }}>
                              {u.name.split(" ").slice(0,2).map(n => n[0]).join("")}
                            </span>
                          </div>
                          <span style={{ color: "#1a2332", fontSize: "0.78rem" }}>{u.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3" style={{ color: "#6b7a8d", fontSize: "0.75rem" }}>{u.email}</td>
                      <td className="px-4 py-3">
                        <span className="px-2 py-0.5 rounded-full" style={{ background: rc.bg, color: rc.text, fontSize: "0.7rem", fontWeight: 600 }}>{u.role}</span>
                      </td>
                      <td className="px-4 py-3" style={{ color: "#374151", fontSize: "0.75rem" }}>{u.area}</td>
                      <td className="px-4 py-3">
                        <span className="px-2 py-0.5 rounded-full" style={{
                          background: u.status === "Activo" ? "rgba(46,139,87,0.1)" : "rgba(192,57,43,0.1)",
                          color: u.status === "Activo" ? "#2E8B57" : "#c0392b",
                          fontSize: "0.7rem",
                          fontWeight: 600
                        }}>{u.status}</span>
                      </td>
                      <td className="px-4 py-3" style={{ color: "#9ca3af", fontSize: "0.72rem" }}>{u.lastLogin}</td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1.5">
                          <button className="p-1.5 rounded" style={{ background: "rgba(30,58,95,0.07)", color: "#1E3A5F" }} onClick={e => { e.stopPropagation(); }}>
                            <Edit2 className="w-3 h-3" />
                          </button>
                          <button className="p-1.5 rounded" style={{ background: "rgba(192,57,43,0.07)", color: "#c0392b" }} onClick={e => { e.stopPropagation(); setUsers(prev => prev.filter(x => x.id !== u.id)); }}>
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Permissions panel */}
        <div className="space-y-4">
          <div className="rounded-xl shadow-sm overflow-hidden" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
            <div className="px-5 py-4" style={{ borderBottom: "1px solid rgba(30,58,95,0.08)", background: "#f8f9fb" }}>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4" style={{ color: "#1E3A5F" }} />
                <h3 style={{ color: "#1E3A5F", fontSize: "0.9rem", fontWeight: 600 }}>Permisos del Rol</h3>
              </div>
              {selectedUser && (
                <p style={{ color: "#6b7a8d", fontSize: "0.72rem", marginTop: "3px" }}>
                  {selectedUser.name} — {selectedUser.role}
                </p>
              )}
            </div>
            <div className="px-5 py-4">
              {!selectedUser ? (
                <p style={{ color: "#9ca3af", fontSize: "0.8rem", textAlign: "center", padding: "20px 0" }}>
                  Seleccione un usuario para ver sus permisos
                </p>
              ) : (
                <div className="space-y-2">
                  {(PERMISSIONS[selectedUser.role] ?? []).map(perm => (
                    <div key={perm} className="flex items-center gap-3 py-2" style={{ borderBottom: "1px solid rgba(30,58,95,0.05)" }}>
                      <div className="w-1.5 h-1.5 rounded-full" style={{ background: "#2E8B57" }} />
                      <span style={{ color: "#374151", fontSize: "0.78rem" }}>{perm}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Role matrix */}
          <div className="rounded-xl p-5 shadow-sm" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
            <h4 style={{ color: "#1E3A5F", fontSize: "0.85rem", fontWeight: 600, marginBottom: "12px" }}>Matriz de Roles</h4>
            {Object.entries(PERMISSIONS).map(([role, perms]) => (
              <div key={role} className="mb-3">
                <div className="flex items-center justify-between mb-1.5">
                  <span style={{ color: "#374151", fontSize: "0.78rem", fontWeight: 600 }}>{role}</span>
                  <span style={{ color: "#6b7a8d", fontSize: "0.7rem" }}>{perms.length} permisos</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {perms.slice(0, 4).map(p => (
                    <span key={p} className="px-1.5 py-0.5 rounded" style={{ background: "rgba(30,58,95,0.07)", color: "#1E3A5F", fontSize: "0.65rem" }}>{p.split(" ").slice(-1)}</span>
                  ))}
                  {perms.length > 4 && (
                    <span className="px-1.5 py-0.5 rounded" style={{ background: "rgba(30,58,95,0.07)", color: "#6b7a8d", fontSize: "0.65rem" }}>+{perms.length - 4}</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* New user modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.45)" }}>
          <div className="rounded-xl shadow-2xl w-full max-w-md mx-4" style={{ background: "#fff" }}>
            <div className="px-6 py-4" style={{ borderBottom: "1px solid rgba(30,58,95,0.1)" }}>
              <h3 style={{ color: "#1E3A5F", fontSize: "1rem", fontWeight: 600 }}>Nuevo Usuario</h3>
            </div>
            <div className="px-6 py-5 space-y-4">
              {[
                { label: "Nombre completo", key: "name", ph: "Nombres y apellidos" },
                { label: "Correo electrónico", key: "email", ph: "correo@avicola.com" },
              ].map(({ label, key, ph }) => (
                <div key={key}>
                  <label className="block mb-1" style={{ color: "#374151", fontSize: "0.8rem", fontWeight: 500 }}>{label}</label>
                  <input
                    value={(form as any)[key]}
                    onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                    placeholder={ph}
                    className="w-full px-3 py-2 rounded-lg border outline-none"
                    style={{ borderColor: "#d1d5db", background: "#f9fafb", fontSize: "0.85rem", color: "#1a2332" }}
                  />
                </div>
              ))}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block mb-1" style={{ color: "#374151", fontSize: "0.8rem", fontWeight: 500 }}>Rol</label>
                  <select value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value }))} className="w-full px-3 py-2 rounded-lg border outline-none" style={{ borderColor: "#d1d5db", background: "#f9fafb", fontSize: "0.85rem", color: "#1a2332" }}>
                    {["Administrador","Supervisor","Operador"].map(r => <option key={r}>{r}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block mb-1" style={{ color: "#374151", fontSize: "0.8rem", fontWeight: 500 }}>Área</label>
                  <select value={form.area} onChange={e => setForm(f => ({ ...f, area: e.target.value }))} className="w-full px-3 py-2 rounded-lg border outline-none" style={{ borderColor: "#d1d5db", background: "#f9fafb", fontSize: "0.85rem", color: "#1a2332" }}>
                    <option value="">Seleccionar...</option>
                    {["Gerencia General","Incubación","Crianza","Engorde","Beneficio","Empaque","Almacén"].map(a => <option key={a}>{a}</option>)}
                  </select>
                </div>
              </div>
            </div>
            <div className="px-6 py-4 flex justify-end gap-3" style={{ borderTop: "1px solid rgba(30,58,95,0.08)" }}>
              <button onClick={() => setShowModal(false)} className="px-4 py-2 rounded-lg" style={{ background: "#f3f4f6", color: "#374151", fontSize: "0.82rem" }}>Cancelar</button>
              <button
                onClick={() => {
                  if (form.name && form.email) {
                    setUsers(prev => [...prev, { ...form, id: `USR-00${prev.length + 1}`, lastLogin: "—" }]);
                    setShowModal(false);
                  }
                }}
                className="px-4 py-2 rounded-lg text-white"
                style={{ background: "#1E3A5F", fontSize: "0.82rem" }}
              >Crear Usuario</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
