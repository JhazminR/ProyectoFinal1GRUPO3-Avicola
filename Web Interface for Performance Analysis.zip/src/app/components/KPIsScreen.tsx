import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  LineChart, Line, Area, AreaChart
} from "recharts";
import { TrendingUp, TrendingDown, Minus, Award } from "lucide-react";

const radarData = [
  { metric: "Puntualidad", value: 88 },
  { metric: "Calidad", value: 92 },
  { metric: "Cantidad", value: 78 },
  { metric: "Seguridad", value: 95 },
  { metric: "Colaboración", value: 82 },
  { metric: "Iniciativa", value: 74 },
];

const areaProductivity = [
  { area: "Incubación", prod: 92, meta: 90, eff: 96 },
  { area: "Crianza", prod: 78, meta: 85, eff: 82 },
  { area: "Engorde", prod: 88, meta: 85, eff: 91 },
  { area: "Beneficio", prod: 95, meta: 90, eff: 98 },
  { area: "Empaque", prod: 73, meta: 80, eff: 77 },
  { area: "Almacén", prod: 84, meta: 85, eff: 89 },
];

const weekTrend = [
  { day: "Lun", actividades: 42, horas: 312 },
  { day: "Mar", actividades: 38, horas: 286 },
  { day: "Mié", actividades: 51, horas: 374 },
  { day: "Jue", actividades: 46, horas: 344 },
  { day: "Vie", actividades: 55, horas: 408 },
  { day: "Sáb", actividades: 28, horas: 196 },
  { day: "Hoy", actividades: 47, horas: 342 },
];

const topWorkers = [
  { name: "Pedro Juan Vargas López", area: "Beneficio", score: 97, rank: 1 },
  { name: "Carlos Alberto Mamani", area: "Incubación", score: 94, rank: 2 },
  { name: "Jorge Antonio Flores", area: "Incubación", score: 91, rank: 3 },
  { name: "María Isabel Ccolque", area: "Engorde", score: 88, rank: 4 },
  { name: "Luis Fernando Huanca", area: "Almacén", score: 85, rank: 5 },
];

const kpis = [
  { label: "Eficiencia Operativa Global", value: "87.3%", prev: "85.1%", trend: "up", icon: TrendingUp, color: "#2E8B57" },
  { label: "Actividades Completadas", value: "847", prev: "760", trend: "up", icon: TrendingUp, color: "#1E3A5F" },
  { label: "Horas Productivas Totales", value: "6,240h", prev: "5,980h", trend: "up", icon: TrendingUp, color: "#3498db" },
  { label: "Áreas Bajo Meta", value: "2", prev: "3", trend: "up", icon: TrendingDown, color: "#e67e22" },
];

export function KPIsScreen() {
  return (
    <div className="p-6 space-y-5 overflow-y-auto h-full">
      {/* KPI cards */}
      <div className="grid grid-cols-4 gap-4">
        {kpis.map(({ label, value, prev, trend, icon: Icon, color }) => (
          <div key={label} className="rounded-xl p-4 shadow-sm" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
            <div className="flex items-start justify-between mb-2">
              <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: `${color}18` }}>
                <Icon className="w-4 h-4" style={{ color }} />
              </div>
              <span style={{ color: trend === "up" ? "#2E8B57" : "#c0392b", fontSize: "0.72rem", fontWeight: 500 }}>
                vs {prev}
              </span>
            </div>
            <div style={{ color: "#1a2332", fontSize: "1.3rem", fontWeight: 700 }}>{value}</div>
            <div style={{ color: "#6b7a8d", fontSize: "0.73rem", lineHeight: 1.4, marginTop: "3px" }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Charts row 1 */}
      <div className="grid grid-cols-3 gap-4">
        {/* Area productivity bar */}
        <div className="col-span-2 rounded-xl p-5 shadow-sm" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
          <h3 style={{ color: "#1E3A5F", fontSize: "0.9rem", fontWeight: 600, marginBottom: "4px" }}>Productividad por Área</h3>
          <p style={{ color: "#6b7a8d", fontSize: "0.75rem", marginBottom: "16px" }}>Productividad real vs eficiencia — Junio 2026</p>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={areaProductivity} barGap={3}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(30,58,95,0.07)" vertical={false} />
              <XAxis dataKey="area" tick={{ fontSize: 11, fill: "#6b7a8d" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#6b7a8d" }} axisLine={false} tickLine={false} domain={[60, 100]} />
              <Tooltip />
              <Bar dataKey="prod" name="Productividad" fill="#1E3A5F" radius={[3, 3, 0, 0]} barSize={16} />
              <Bar dataKey="eff" name="Eficiencia" fill="#2E8B57" radius={[3, 3, 0, 0]} barSize={16} opacity={0.8} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Radar */}
        <div className="rounded-xl p-5 shadow-sm" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
          <h3 style={{ color: "#1E3A5F", fontSize: "0.9rem", fontWeight: 600, marginBottom: "4px" }}>Perfil de Rendimiento</h3>
          <p style={{ color: "#6b7a8d", fontSize: "0.75rem", marginBottom: "8px" }}>Indicadores multi-dimensionales</p>
          <ResponsiveContainer width="100%" height={200}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="rgba(30,58,95,0.15)" />
              <PolarAngleAxis dataKey="metric" tick={{ fontSize: 10, fill: "#6b7a8d" }} />
              <Radar name="Rendimiento" dataKey="value" stroke="#1E3A5F" fill="#1E3A5F" fillOpacity={0.25} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts row 2 */}
      <div className="grid grid-cols-3 gap-4">
        {/* Weekly trend */}
        <div className="col-span-2 rounded-xl p-5 shadow-sm" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
          <h3 style={{ color: "#1E3A5F", fontSize: "0.9rem", fontWeight: 600, marginBottom: "4px" }}>Tendencia Semanal de Actividades</h3>
          <p style={{ color: "#6b7a8d", fontSize: "0.75rem", marginBottom: "16px" }}>Actividades registradas por día</p>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={weekTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(30,58,95,0.07)" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: "#6b7a8d" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#6b7a8d" }} axisLine={false} tickLine={false} />
              <Tooltip />
              <Area type="monotone" dataKey="actividades" stroke="#1E3A5F" fill="rgba(30,58,95,0.08)" strokeWidth={2} name="Actividades" />
              <Line type="monotone" dataKey="horas" stroke="#2E8B57" strokeWidth={2} dot={false} name="Horas" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Top workers */}
        <div className="rounded-xl p-5 shadow-sm" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
          <div className="flex items-center gap-2 mb-4">
            <Award className="w-4 h-4" style={{ color: "#e67e22" }} />
            <h3 style={{ color: "#1E3A5F", fontSize: "0.9rem", fontWeight: 600 }}>Top Trabajadores</h3>
          </div>
          <div className="space-y-3">
            {topWorkers.map(({ name, area, score, rank }) => (
              <div key={name} className="flex items-center gap-3">
                <div
                  className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 font-bold"
                  style={{
                    background: rank === 1 ? "#e67e22" : rank === 2 ? "#9b59b6" : rank === 3 ? "#3498db" : "#e8ecf0",
                    color: rank <= 3 ? "#fff" : "#6b7a8d",
                    fontSize: "0.72rem"
                  }}
                >{rank}</div>
                <div className="flex-1 min-w-0">
                  <div style={{ color: "#1a2332", fontSize: "0.78rem", fontWeight: 500 }} className="truncate">{name}</div>
                  <div style={{ color: "#6b7a8d", fontSize: "0.7rem" }}>{area}</div>
                </div>
                <span style={{ color: "#2E8B57", fontSize: "0.82rem", fontWeight: 700 }}>{score}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
