import { useState } from "react";
import { Download, FileText, Filter, Search } from "lucide-react";

const allResults = [
  { worker: "Carlos Alberto Mamani Quispe", area: "Incubación", activities: 24, hours: 184, productivity: 94, period: "Jun 2026" },
  { worker: "Rosa Elena Quispe Huanca", area: "Crianza", activities: 20, hours: 152, productivity: 80, period: "Jun 2026" },
  { worker: "Pedro Juan Vargas López", area: "Beneficio", activities: 18, hours: 138, productivity: 97, period: "Jun 2026" },
  { worker: "Ana María Torres Ccopa", area: "Empaque", activities: 22, hours: 164, productivity: 76, period: "Jun 2026" },
  { worker: "Luis Fernando Huanca Chura", area: "Almacén y Frío", activities: 15, hours: 112, productivity: 85, period: "Jun 2026" },
  { worker: "María Isabel Ccolque Ramos", area: "Engorde", activities: 21, hours: 160, productivity: 88, period: "Jun 2026" },
  { worker: "Jorge Antonio Flores Mami", area: "Incubación", activities: 19, hours: 142, productivity: 91, period: "Jun 2026" },
  { worker: "Carmen Luz Apaza Ticona", area: "Crianza", activities: 23, hours: 174, productivity: 78, period: "Jun 2026" },
  { worker: "Roberto Carlos Mamani Yujra", area: "Beneficio", activities: 17, hours: 130, productivity: 93, period: "Jun 2026" },
  { worker: "Sandra Patricia Poma Condori", area: "Empaque", activities: 12, hours: 88, productivity: 67, period: "Jun 2026" },
];

export function ReportsScreen() {
  const [workerFilter, setWorkerFilter] = useState("");
  const [areaFilter, setAreaFilter] = useState("Todas");
  const [dateFrom, setDateFrom] = useState("2026-06-01");
  const [dateTo, setDateTo] = useState("2026-06-17");

  const filtered = allResults.filter(r => {
    const matchWorker = r.worker.toLowerCase().includes(workerFilter.toLowerCase());
    const matchArea = areaFilter === "Todas" || r.area === areaFilter;
    return matchWorker && matchArea;
  });

  const totalHours = filtered.reduce((s, r) => s + r.hours, 0);
  const avgProd = filtered.length ? Math.round(filtered.reduce((s, r) => s + r.productivity, 0) / filtered.length) : 0;

  const prodColor = (p: number) => p >= 90 ? "#2E8B57" : p >= 80 ? "#1E3A5F" : p >= 70 ? "#e67e22" : "#c0392b";

  const handleExport = (type: "PDF" | "Excel") => {
    alert(`Exportando reporte en formato ${type}...\n(Funcionalidad disponible en producción con backend integrado)`);
  };

  return (
    <div className="p-6 space-y-5 overflow-y-auto h-full">
      {/* Filters card */}
      <div className="rounded-xl p-5 shadow-sm" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
        <div className="flex items-center gap-2 mb-4">
          <Filter className="w-4 h-4" style={{ color: "#1E3A5F" }} />
          <h3 style={{ color: "#1E3A5F", fontSize: "0.9rem", fontWeight: 600 }}>Filtros de Búsqueda</h3>
        </div>
        <div className="grid grid-cols-4 gap-4">
          <div>
            <label className="block mb-1.5" style={{ color: "#374151", fontSize: "0.78rem", fontWeight: 500 }}>Trabajador</label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2" style={{ color: "#9ca3af" }} />
              <input
                value={workerFilter}
                onChange={e => setWorkerFilter(e.target.value)}
                placeholder="Nombre del trabajador"
                className="w-full pl-8 pr-3 py-2 rounded-lg border outline-none"
                style={{ borderColor: "#e5e7eb", background: "#f9fafb", fontSize: "0.82rem", color: "#374151" }}
              />
            </div>
          </div>
          <div>
            <label className="block mb-1.5" style={{ color: "#374151", fontSize: "0.78rem", fontWeight: 500 }}>Área</label>
            <select
              value={areaFilter}
              onChange={e => setAreaFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border outline-none"
              style={{ borderColor: "#e5e7eb", background: "#f9fafb", fontSize: "0.82rem", color: "#374151" }}
            >
              {["Todas","Incubación","Crianza","Engorde","Beneficio","Empaque","Almacén y Frío"].map(a => <option key={a}>{a}</option>)}
            </select>
          </div>
          <div>
            <label className="block mb-1.5" style={{ color: "#374151", fontSize: "0.78rem", fontWeight: 500 }}>Desde</label>
            <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="w-full px-3 py-2 rounded-lg border outline-none" style={{ borderColor: "#e5e7eb", background: "#f9fafb", fontSize: "0.82rem", color: "#374151" }} />
          </div>
          <div>
            <label className="block mb-1.5" style={{ color: "#374151", fontSize: "0.78rem", fontWeight: 500 }}>Hasta</label>
            <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="w-full px-3 py-2 rounded-lg border outline-none" style={{ borderColor: "#e5e7eb", background: "#f9fafb", fontSize: "0.82rem", color: "#374151" }} />
          </div>
        </div>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Registros encontrados", value: filtered.length },
          { label: "Total actividades", value: filtered.reduce((s, r) => s + r.activities, 0) },
          { label: "Total horas registradas", value: `${totalHours}h` },
          { label: "Productividad promedio", value: `${avgProd}%` },
        ].map(({ label, value }) => (
          <div key={label} className="rounded-lg px-4 py-3" style={{ background: "rgba(30,58,95,0.05)", border: "1px solid rgba(30,58,95,0.08)" }}>
            <div style={{ color: "#1E3A5F", fontSize: "1.2rem", fontWeight: 700 }}>{value}</div>
            <div style={{ color: "#6b7a8d", fontSize: "0.72rem" }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Table */}
      <div className="rounded-xl shadow-sm overflow-hidden" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
        <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: "1px solid rgba(30,58,95,0.07)" }}>
          <h3 style={{ color: "#1E3A5F", fontSize: "0.9rem", fontWeight: 600 }}>Resultados del Reporte</h3>
          <div className="flex gap-2">
            <button
              onClick={() => handleExport("PDF")}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg"
              style={{ background: "rgba(192,57,43,0.08)", color: "#c0392b", fontSize: "0.78rem", fontWeight: 500, border: "1px solid rgba(192,57,43,0.2)" }}
            >
              <FileText className="w-3.5 h-3.5" /> Exportar PDF
            </button>
            <button
              onClick={() => handleExport("Excel")}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg"
              style={{ background: "rgba(46,139,87,0.08)", color: "#2E8B57", fontSize: "0.78rem", fontWeight: 500, border: "1px solid rgba(46,139,87,0.2)" }}
            >
              <Download className="w-3.5 h-3.5" /> Exportar Excel
            </button>
          </div>
        </div>
        <table className="w-full">
          <thead>
            <tr style={{ background: "#f8f9fb" }}>
              {["Trabajador","Área","Actividades","Horas Totales","Productividad","Período"].map(h => (
                <th key={h} className="px-5 py-3 text-left" style={{ color: "#6b7a8d", fontSize: "0.72rem", fontWeight: 600, letterSpacing: "0.04em" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((r, i) => {
              const pColor = prodColor(r.productivity);
              return (
                <tr key={r.worker} style={{ borderTop: "1px solid rgba(30,58,95,0.05)", background: i % 2 === 0 ? "#fff" : "#fafbfc" }}>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: "#1E3A5F" }}>
                        <span className="text-white" style={{ fontSize: "0.6rem", fontWeight: 700 }}>
                          {r.worker.split(" ").slice(0,2).map(n => n[0]).join("")}
                        </span>
                      </div>
                      <span style={{ color: "#1a2332", fontSize: "0.82rem" }}>{r.worker}</span>
                    </div>
                  </td>
                  <td className="px-5 py-3">
                    <span className="px-2.5 py-1 rounded-md" style={{ background: "rgba(30,58,95,0.07)", color: "#1E3A5F", fontSize: "0.75rem" }}>{r.area}</span>
                  </td>
                  <td className="px-5 py-3" style={{ color: "#374151", fontSize: "0.82rem", fontWeight: 500 }}>{r.activities}</td>
                  <td className="px-5 py-3" style={{ color: "#374151", fontSize: "0.82rem" }}>{r.hours}h</td>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1.5 rounded-full" style={{ background: "#e8ecf0", maxWidth: "60px" }}>
                        <div className="h-full rounded-full" style={{ width: `${r.productivity}%`, background: pColor }} />
                      </div>
                      <span style={{ color: pColor, fontSize: "0.8rem", fontWeight: 700 }}>{r.productivity}%</span>
                    </div>
                  </td>
                  <td className="px-5 py-3" style={{ color: "#6b7a8d", fontSize: "0.78rem" }}>{r.period}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div className="py-10 text-center" style={{ color: "#6b7a8d", fontSize: "0.85rem" }}>Sin resultados para los filtros aplicados.</div>
        )}
      </div>
    </div>
  );
}
