import {
  LayoutDashboard, Users, MapPin, ClipboardList,
  BarChart2, Activity, UserCog, ChevronRight, Feather, LogOut, Bell
} from "lucide-react";

export type Screen =
  | "dashboard" | "workers" | "areas" | "activities"
  | "reports" | "kpis" | "users";

interface SidebarProps {
  current: Screen;
  onNavigate: (s: Screen) => void;
  onLogout: () => void;
  collapsed?: boolean;
}

const NAV = [
  { id: "dashboard" as Screen, label: "Dashboard", icon: LayoutDashboard },
  { id: "workers" as Screen, label: "Trabajadores", icon: Users },
  { id: "areas" as Screen, label: "Áreas de Producción", icon: MapPin },
  { id: "activities" as Screen, label: "Registro de Actividades", icon: ClipboardList },
  { id: "reports" as Screen, label: "Reportes", icon: BarChart2 },
  { id: "kpis" as Screen, label: "Indicadores KPI", icon: Activity },
  { id: "users" as Screen, label: "Gestión de Usuarios", icon: UserCog },
];

export function Sidebar({ current, onNavigate, onLogout }: SidebarProps) {
  return (
    <aside
      className="flex flex-col h-screen select-none"
      style={{
        width: "240px",
        minWidth: "240px",
        background: "linear-gradient(180deg, #152a45 0%, #1E3A5F 100%)",
        borderRight: "1px solid rgba(255,255,255,0.06)"
      }}
    >
      {/* Logo */}
      <div className="px-5 py-5" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: "#2E8B57" }}>
            <Feather className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="text-white font-bold leading-tight" style={{ fontSize: "0.85rem" }}>AVÍCOLA ANDINA</div>
            <div style={{ color: "#6a85a0", fontSize: "0.65rem", letterSpacing: "0.08em" }}>RENDIMIENTO LABORAL</div>
          </div>
        </div>
      </div>

      {/* Nav label */}
      <div className="px-5 pt-5 pb-2">
        <span style={{ color: "#4e6a84", fontSize: "0.65rem", fontWeight: 600, letterSpacing: "0.1em" }}>MENÚ PRINCIPAL</span>
      </div>

      {/* Nav items */}
      <nav className="flex-1 px-3 space-y-0.5 overflow-y-auto">
        {NAV.map(({ id, label, icon: Icon }) => {
          const active = current === id;
          return (
            <button
              key={id}
              onClick={() => onNavigate(id)}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-left"
              style={{
                background: active ? "rgba(46,139,87,0.18)" : "transparent",
                color: active ? "#3aa368" : "#a0b8cc",
                borderLeft: active ? "3px solid #2E8B57" : "3px solid transparent",
                fontSize: "0.82rem"
              }}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              <span className="flex-1">{label}</span>
              {active && <ChevronRight className="w-3.5 h-3.5 opacity-60" />}
            </button>
          );
        })}
      </nav>

      {/* User info */}
      <div className="px-3 pb-4" style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}>
        <div className="flex items-center gap-3 px-3 py-3 rounded-lg mt-3" style={{ background: "rgba(255,255,255,0.04)" }}>
          <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: "#2E8B57" }}>
            <span className="text-white font-bold" style={{ fontSize: "0.75rem" }}>JR</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-white truncate" style={{ fontSize: "0.78rem", fontWeight: 500 }}>Juan Rodríguez</div>
            <div style={{ color: "#4e6a84", fontSize: "0.68rem" }}>Administrador</div>
          </div>
          <div className="flex gap-1">
            <button className="p-1.5 rounded transition-colors" style={{ color: "#4e6a84" }}>
              <Bell className="w-3.5 h-3.5" />
            </button>
            <button onClick={onLogout} className="p-1.5 rounded transition-colors" style={{ color: "#4e6a84" }}>
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}
