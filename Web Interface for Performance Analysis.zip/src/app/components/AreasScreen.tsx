import { useState } from "react";
import { Plus, Users, Edit2, Trash2, MapPin, TrendingUp } from "lucide-react";

const initialAreas = [
  { id: "AREA-01", name: "Incubación", description: "Control y gestión del proceso de incubación de huevos fértiles", workers: 22, supervisor: "Ing. Marco Quispe", capacity: 30, status: "Operativo", productivity: 92 },
  { id: "AREA-02", name: "Crianza", description: "Cría y desarrollo de pollos desde el nacimiento hasta pre-engorde", workers: 35, supervisor: "Ing. Silvia Mamani", capacity: 40, status: "Operativo", productivity: 78 },
  { id: "AREA-03", name: "Engorde", description: "Engorde y preparación de pollos para beneficio", workers: 28, supervisor: "Tec. Roberto Vargas", capacity: 35, status: "Operativo", productivity: 88 },
  { id: "AREA-04", name: "Beneficio", description: "Procesamiento, faenado y beneficio de aves", workers: 31, supervisor: "Ing. Patricia Torres", capacity: 35, status: "Operativo", productivity: 95 },
  { id: "AREA-05", name: "Empaque", description: "Clasificación, empaque y presentación del producto final", workers: 18, supervisor: "Tec. Juan Flores", capacity: 25, status: "Operativo", productivity: 73 },
  { id: "AREA-06", name: "Almacén y Frío", description: "Almacenamiento en cámara frigorífica y despacho", workers: 14, supervisor: "Tec. Ana Condori", capacity: 20, status: "Mantenimiento", productivity: 84 },
];

export function AreasScreen() {
  const [areas, setAreas] = useState(initialAreas);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ id: "", name: "", description: "", supervisor: "", capacity: "" });

  const colorForProductivity = (p: number) =>
    p >= 90 ? "#2E8B57" : p >= 80 ? "#1E3A5F" : "#e67e22";

  return (
    <div className="p-6 space-y-5 overflow-y-auto h-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <p style={{ color: "#6b7a8d", fontSize: "0.8rem" }}>{areas.length} áreas productivas registradas</p>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg text-white"
          style={{ background: "linear-gradient(90deg, #1E3A5F, #243f6b)", fontSize: "0.82rem" }}
        >
          <Plus className="w-4 h-4" /> Nueva Área
        </button>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Total Trabajadores", value: areas.reduce((s, a) => s + a.workers, 0), sub: "en todas las áreas", color: "#1E3A5F" },
          { label: "Capacidad Total", value: areas.reduce((s, a) => s + a.capacity, 0), sub: "puestos disponibles", color: "#2E8B57" },
          { label: "Productividad Prom.", value: `${Math.round(areas.reduce((s, a) => s + a.productivity, 0) / areas.length)}%`, sub: "promedio del sistema", color: "#e67e22" },
        ].map(({ label, value, sub, color }) => (
          <div key={label} className="rounded-xl p-4 shadow-sm" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
            <div style={{ color, fontSize: "1.5rem", fontWeight: 700 }}>{value}</div>
            <div style={{ color: "#1a2332", fontSize: "0.82rem", fontWeight: 500, marginTop: "2px" }}>{label}</div>
            <div style={{ color: "#6b7a8d", fontSize: "0.72rem" }}>{sub}</div>
          </div>
        ))}
      </div>

      {/* Areas grid */}
      <div className="grid grid-cols-2 gap-4">
        {areas.map((area) => {
          const pct = Math.round((area.workers / area.capacity) * 100);
          const prodColor = colorForProductivity(area.productivity);
          return (
            <div key={area.id} className="rounded-xl p-5 shadow-sm" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: "rgba(30,58,95,0.08)" }}>
                    <MapPin className="w-5 h-5" style={{ color: "#1E3A5F" }} />
                  </div>
                  <div>
                    <div style={{ color: "#1E3A5F", fontSize: "0.92rem", fontWeight: 600 }}>{area.name}</div>
                    <div style={{ color: "#6b7a8d", fontSize: "0.72rem" }}>{area.id}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-full" style={{
                    background: area.status === "Operativo" ? "rgba(46,139,87,0.1)" : "rgba(230,126,34,0.1)",
                    color: area.status === "Operativo" ? "#2E8B57" : "#e67e22",
                    fontSize: "0.7rem",
                    fontWeight: 600
                  }}>{area.status}</span>
                  <button onClick={() => setAreas(prev => prev.filter(a => a.id !== area.id))} className="p-1.5 rounded" style={{ color: "#c0392b" }}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <p style={{ color: "#6b7a8d", fontSize: "0.78rem", lineHeight: 1.5, marginBottom: "12px" }}>{area.description}</p>
              {/* Workers bar */}
              <div className="mb-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="flex items-center gap-1.5" style={{ color: "#374151", fontSize: "0.75rem" }}>
                    <Users className="w-3.5 h-3.5" /> {area.workers} / {area.capacity} trabajadores
                  </span>
                  <span style={{ color: "#6b7a8d", fontSize: "0.72rem" }}>{pct}%</span>
                </div>
                <div className="h-1.5 rounded-full" style={{ background: "#e8ecf0" }}>
                  <div className="h-full rounded-full" style={{ width: `${pct}%`, background: "#1E3A5F" }} />
                </div>
              </div>
              {/* Productivity */}
              <div className="flex items-center justify-between">
                <span style={{ color: "#6b7a8d", fontSize: "0.75rem" }}>
                  <span className="font-medium" style={{ color: "#374151" }}>Supervisor:</span> {area.supervisor}
                </span>
                <div className="flex items-center gap-1.5">
                  <TrendingUp className="w-3.5 h-3.5" style={{ color: prodColor }} />
                  <span style={{ color: prodColor, fontSize: "0.8rem", fontWeight: 700 }}>{area.productivity}%</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.45)" }}>
          <div className="rounded-xl shadow-2xl w-full max-w-md mx-4" style={{ background: "#fff" }}>
            <div className="px-6 py-4" style={{ borderBottom: "1px solid rgba(30,58,95,0.1)" }}>
              <h3 style={{ color: "#1E3A5F", fontSize: "1rem", fontWeight: 600 }}>Registrar Nueva Área</h3>
            </div>
            <div className="px-6 py-5 space-y-4">
              {[
                { label: "Código", key: "id", ph: "AREA-07" },
                { label: "Nombre del Área", key: "name", ph: "Nombre del área productiva" },
                { label: "Supervisor", key: "supervisor", ph: "Nombre del supervisor" },
                { label: "Descripción", key: "description", ph: "Descripción de actividades" },
                { label: "Capacidad (puestos)", key: "capacity", ph: "Número máximo de trabajadores" },
              ].map(({ label, key, ph }) => (
                <div key={key}>
                  <label className="block mb-1" style={{ color: "#374151", fontSize: "0.8rem", fontWeight: 500 }}>{label}</label>
                  <input
                    value={(form as any)[key]}
                    onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                    placeholder={ph}
                    className="w-full px-3 py-2 rounded-lg border outline-none"
                    style={{ borderColor: "#d1d5db", background: "#f9fafb", fontSize: "0.85rem", color: "#1a2332" }}
                  />
                </div>
              ))}
            </div>
            <div className="px-6 py-4 flex justify-end gap-3" style={{ borderTop: "1px solid rgba(30,58,95,0.08)" }}>
              <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg" style={{ background: "#f3f4f6", color: "#374151", fontSize: "0.82rem" }}>Cancelar</button>
              <button
                onClick={() => {
                  if (form.name) {
                    setAreas(prev => [...prev, {
                      ...form,
                      workers: 0,
                      capacity: parseInt(form.capacity) || 20,
                      status: "Operativo",
                      productivity: 0
                    }]);
                    setShowForm(false);
                    setForm({ id: "", name: "", description: "", supervisor: "", capacity: "" });
                  }
                }}
                className="px-4 py-2 rounded-lg text-white"
                style={{ background: "#1E3A5F", fontSize: "0.82rem" }}
              >Guardar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
