import { useState } from "react";
import { Save, CheckCircle } from "lucide-react";

const WORKERS = [
  "Carlos Alberto Mamani Quispe",
  "Rosa Elena Quispe Huanca",
  "Pedro Juan Vargas López",
  "Ana María Torres Ccopa",
  "Luis Fernando Huanca Chura",
  "María Isabel Ccolque Ramos",
];

const AREAS = ["Incubación", "Crianza", "Engorde", "Beneficio", "Empaque", "Almacén y Frío"];

const ACTIVITIES_BY_AREA: Record<string, string[]> = {
  "Incubación": ["Control de temperatura", "Volteo de huevos", "Supervisión de incubadoras", "Registro de nacimientos"],
  "Crianza": ["Alimentación de lote", "Control sanitario", "Vacunación preventiva", "Registro de bajas"],
  "Engorde": ["Distribución de alimento balanceado", "Control de peso", "Desinfección de galpones"],
  "Beneficio": ["Supervisión de línea de corte", "Control de calidad", "Mantenimiento de equipos"],
  "Empaque": ["Clasificación de producto", "Etiquetado y sellado", "Control de trazabilidad"],
  "Almacén y Frío": ["Control de temperatura de cámara", "Inventario de productos", "Despacho de pedidos"],
};

const recentRecords = [
  { id: "ACT-089", worker: "Carlos Alberto Mamani Quispe", area: "Incubación", activity: "Control de temperatura", date: "17/06/2026", hours: 8, obs: "Sin incidencias" },
  { id: "ACT-090", worker: "Rosa Elena Quispe Huanca", area: "Crianza", activity: "Alimentación de lote", date: "17/06/2026", hours: 7.5, obs: "Lote A y B completados" },
  { id: "ACT-091", worker: "Pedro Juan Vargas López", area: "Beneficio", activity: "Supervisión de línea de corte", date: "16/06/2026", hours: 6, obs: "Equipo 3 en revisión" },
];

export function ActivitiesScreen() {
  const [form, setForm] = useState({
    worker: "",
    area: "",
    activity: "",
    date: new Date().toISOString().split("T")[0],
    hours: "",
    observations: "",
  });
  const [saved, setSaved] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const availableActivities = form.area ? (ACTIVITIES_BY_AREA[form.area] ?? []) : [];

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.worker) e.worker = "Seleccione un trabajador";
    if (!form.area) e.area = "Seleccione un área";
    if (!form.activity) e.activity = "Seleccione una actividad";
    if (!form.date) e.date = "Ingrese la fecha";
    if (!form.hours || isNaN(Number(form.hours))) e.hours = "Ingrese horas válidas";
    return e;
  };

  const handleSave = () => {
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length === 0) {
      setSaved(true);
      setTimeout(() => {
        setSaved(false);
        setForm({ worker: "", area: "", activity: "", date: new Date().toISOString().split("T")[0], hours: "", observations: "" });
      }, 2200);
    }
  };

  const inputStyle = (field: string) => ({
    borderColor: errors[field] ? "#c0392b" : "#d1d5db",
    background: "#f9fafb",
    fontSize: "0.85rem" as const,
    color: "#1a2332"
  });

  const Field = ({ label, field, children }: { label: string; field: string; children: React.ReactNode }) => (
    <div>
      <label className="block mb-1" style={{ color: "#374151", fontSize: "0.82rem", fontWeight: 500 }}>{label}</label>
      {children}
      {errors[field] && <p style={{ color: "#c0392b", fontSize: "0.72rem", marginTop: "3px" }}>{errors[field]}</p>}
    </div>
  );

  return (
    <div className="p-6 overflow-y-auto h-full">
      <div className="grid grid-cols-5 gap-6">
        {/* Form */}
        <div className="col-span-3">
          <div className="rounded-xl shadow-sm overflow-hidden" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
            <div className="px-6 py-4" style={{ borderBottom: "1px solid rgba(30,58,95,0.08)", background: "#f8f9fb" }}>
              <h3 style={{ color: "#1E3A5F", fontSize: "0.92rem", fontWeight: 600 }}>Formulario de Registro</h3>
              <p style={{ color: "#6b7a8d", fontSize: "0.75rem" }}>Complete todos los campos obligatorios</p>
            </div>
            <div className="px-6 py-5 space-y-4">
              {/* Worker */}
              <Field label="Trabajador *" field="worker">
                <select
                  value={form.worker}
                  onChange={e => setForm(f => ({ ...f, worker: e.target.value }))}
                  className="w-full px-3 py-2.5 rounded-lg border outline-none"
                  style={inputStyle("worker")}
                >
                  <option value="">Seleccionar trabajador...</option>
                  {WORKERS.map(w => <option key={w}>{w}</option>)}
                </select>
              </Field>

              {/* Area + Activity */}
              <div className="grid grid-cols-2 gap-4">
                <Field label="Área de Producción *" field="area">
                  <select
                    value={form.area}
                    onChange={e => setForm(f => ({ ...f, area: e.target.value, activity: "" }))}
                    className="w-full px-3 py-2.5 rounded-lg border outline-none"
                    style={inputStyle("area")}
                  >
                    <option value="">Seleccionar área...</option>
                    {AREAS.map(a => <option key={a}>{a}</option>)}
                  </select>
                </Field>
                <Field label="Actividad Realizada *" field="activity">
                  <select
                    value={form.activity}
                    onChange={e => setForm(f => ({ ...f, activity: e.target.value }))}
                    className="w-full px-3 py-2.5 rounded-lg border outline-none"
                    style={inputStyle("activity")}
                    disabled={!form.area}
                  >
                    <option value="">Seleccionar actividad...</option>
                    {availableActivities.map(a => <option key={a}>{a}</option>)}
                  </select>
                </Field>
              </div>

              {/* Date + Hours */}
              <div className="grid grid-cols-2 gap-4">
                <Field label="Fecha *" field="date">
                  <input
                    type="date"
                    value={form.date}
                    onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                    className="w-full px-3 py-2.5 rounded-lg border outline-none"
                    style={inputStyle("date")}
                  />
                </Field>
                <Field label="Horas Trabajadas *" field="hours">
                  <input
                    type="number"
                    min="0.5"
                    max="12"
                    step="0.5"
                    value={form.hours}
                    onChange={e => setForm(f => ({ ...f, hours: e.target.value }))}
                    placeholder="8.0"
                    className="w-full px-3 py-2.5 rounded-lg border outline-none"
                    style={inputStyle("hours")}
                  />
                </Field>
              </div>

              {/* Observations */}
              <Field label="Observaciones" field="observations">
                <textarea
                  value={form.observations}
                  onChange={e => setForm(f => ({ ...f, observations: e.target.value }))}
                  placeholder="Novedades, incidencias, observaciones del turno..."
                  rows={3}
                  className="w-full px-3 py-2.5 rounded-lg border outline-none resize-none"
                  style={{ borderColor: "#d1d5db", background: "#f9fafb", fontSize: "0.85rem", color: "#1a2332" }}
                />
              </Field>

              {/* Save button */}
              {saved ? (
                <div className="flex items-center justify-center gap-2 py-2.5 rounded-lg" style={{ background: "rgba(46,139,87,0.1)", color: "#2E8B57" }}>
                  <CheckCircle className="w-4 h-4" />
                  <span style={{ fontSize: "0.85rem", fontWeight: 500 }}>Actividad registrada correctamente</span>
                </div>
              ) : (
                <button
                  onClick={handleSave}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-white"
                  style={{ background: "linear-gradient(90deg, #1E3A5F, #243f6b)", fontSize: "0.88rem", fontWeight: 500 }}
                >
                  <Save className="w-4 h-4" /> Guardar Registro
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Recent records */}
        <div className="col-span-2 space-y-4">
          <div className="rounded-xl shadow-sm overflow-hidden" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
            <div className="px-5 py-4" style={{ borderBottom: "1px solid rgba(30,58,95,0.08)", background: "#f8f9fb" }}>
              <h3 style={{ color: "#1E3A5F", fontSize: "0.88rem", fontWeight: 600 }}>Últimos Registros</h3>
            </div>
            <div className="divide-y" style={{ borderColor: "rgba(30,58,95,0.06)" }}>
              {recentRecords.map(r => (
                <div key={r.id} className="px-5 py-3.5">
                  <div className="flex items-start justify-between mb-1">
                    <span style={{ color: "#1E3A5F", fontSize: "0.78rem", fontWeight: 600 }}>{r.id}</span>
                    <span style={{ color: "#6b7a8d", fontSize: "0.72rem" }}>{r.date}</span>
                  </div>
                  <div style={{ color: "#1a2332", fontSize: "0.8rem", fontWeight: 500 }}>{r.worker}</div>
                  <div style={{ color: "#6b7a8d", fontSize: "0.75rem", marginTop: "2px" }}>{r.activity} — {r.area}</div>
                  <div className="flex items-center justify-between mt-2">
                    <span style={{ color: "#374151", fontSize: "0.72rem" }}>⏱ {r.hours}h trabajadas</span>
                    {r.obs && <span style={{ color: "#9ca3af", fontSize: "0.7rem", fontStyle: "italic" }}>{r.obs}</span>}
                  </div>
                </div>
              ))}
            </div>
          </div>
          {/* Quick stats */}
          <div className="rounded-xl p-4 shadow-sm" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
            <h4 style={{ color: "#1E3A5F", fontSize: "0.82rem", fontWeight: 600, marginBottom: "12px" }}>Estadísticas del Día</h4>
            {[
              { label: "Actividades hoy", value: "47" },
              { label: "Horas totales registradas", value: "342h" },
              { label: "Trabajadores activos", value: "38" },
              { label: "Áreas con registros", value: "6/6" },
            ].map(({ label, value }) => (
              <div key={label} className="flex items-center justify-between py-2" style={{ borderBottom: "1px solid rgba(30,58,95,0.05)" }}>
                <span style={{ color: "#6b7a8d", fontSize: "0.78rem" }}>{label}</span>
                <span style={{ color: "#1E3A5F", fontSize: "0.85rem", fontWeight: 600 }}>{value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
