import { useState } from "react";
import { Search, Plus, Edit2, Trash2, Filter, ChevronDown } from "lucide-react";

const initialWorkers = [
  { id: "TRB-001", name: "Carlos Alberto Mamani Quispe", area: "Incubación", cargo: "Operario de Incubación", status: "Activo" },
  { id: "TRB-002", name: "Rosa Elena Quispe Huanca", area: "Crianza", cargo: "Técnico en Crianza", status: "Activo" },
  { id: "TRB-003", name: "Pedro Juan Vargas López", area: "Beneficio", cargo: "Supervisor de Línea", status: "Activo" },
  { id: "TRB-004", name: "Ana María Torres Ccopa", area: "Empaque", cargo: "Operaria de Empaque", status: "Activo" },
  { id: "TRB-005", name: "Luis Fernando Huanca Chura", area: "Almacén", cargo: "Encargado de Almacén", status: "Activo" },
  { id: "TRB-006", name: "María Isabel Ccolque Ramos", area: "Engorde", cargo: "Técnico en Engorde", status: "Activo" },
  { id: "TRB-007", name: "Jorge Antonio Flores Mami", area: "Incubación", cargo: "Operario Senior", status: "Inactivo" },
  { id: "TRB-008", name: "Carmen Luz Apaza Ticona", area: "Crianza", cargo: "Operaria de Crianza", status: "Activo" },
  { id: "TRB-009", name: "Roberto Carlos Mamani Yujra", area: "Beneficio", cargo: "Operario de Beneficio", status: "Activo" },
  { id: "TRB-010", name: "Sandra Patricia Poma Condori", area: "Empaque", cargo: "Clasificadora", status: "Licencia" },
];

interface WorkerModalProps {
  worker?: (typeof initialWorkers)[0] | null;
  onClose: () => void;
  onSave: (w: any) => void;
}

function WorkerModal({ worker, onClose, onSave }: WorkerModalProps) {
  const [form, setForm] = useState(worker ?? { id: "", name: "", area: "", cargo: "", status: "Activo" });
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.45)" }}>
      <div className="rounded-xl shadow-2xl w-full max-w-md mx-4" style={{ background: "#fff" }}>
        <div className="px-6 py-4" style={{ borderBottom: "1px solid rgba(30,58,95,0.1)" }}>
          <h3 style={{ color: "#1E3A5F", fontSize: "1rem", fontWeight: 600 }}>
            {worker ? "Editar Trabajador" : "Registrar Trabajador"}
          </h3>
        </div>
        <div className="px-6 py-5 space-y-4">
          {[
            { label: "Código", key: "id", placeholder: "TRB-011" },
            { label: "Nombre completo", key: "name", placeholder: "Nombres y apellidos" },
            { label: "Cargo", key: "cargo", placeholder: "Cargo o puesto" },
          ].map(({ label, key, placeholder }) => (
            <div key={key}>
              <label className="block mb-1" style={{ color: "#374151", fontSize: "0.8rem", fontWeight: 500 }}>{label}</label>
              <input
                value={(form as any)[key]}
                onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                placeholder={placeholder}
                className="w-full px-3 py-2 rounded-lg border outline-none"
                style={{ borderColor: "#d1d5db", background: "#f9fafb", fontSize: "0.85rem", color: "#1a2332" }}
              />
            </div>
          ))}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block mb-1" style={{ color: "#374151", fontSize: "0.8rem", fontWeight: 500 }}>Área</label>
              <select
                value={form.area}
                onChange={e => setForm(f => ({ ...f, area: e.target.value }))}
                className="w-full px-3 py-2 rounded-lg border outline-none"
                style={{ borderColor: "#d1d5db", background: "#f9fafb", fontSize: "0.85rem", color: "#1a2332" }}
              >
                {["Incubación","Crianza","Engorde","Beneficio","Empaque","Almacén"].map(a => <option key={a}>{a}</option>)}
              </select>
            </div>
            <div>
              <label className="block mb-1" style={{ color: "#374151", fontSize: "0.8rem", fontWeight: 500 }}>Estado</label>
              <select
                value={form.status}
                onChange={e => setForm(f => ({ ...f, status: e.target.value }))}
                className="w-full px-3 py-2 rounded-lg border outline-none"
                style={{ borderColor: "#d1d5db", background: "#f9fafb", fontSize: "0.85rem", color: "#1a2332" }}
              >
                {["Activo","Inactivo","Licencia"].map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
        </div>
        <div className="px-6 py-4 flex justify-end gap-3" style={{ borderTop: "1px solid rgba(30,58,95,0.08)" }}>
          <button onClick={onClose} className="px-4 py-2 rounded-lg" style={{ background: "#f3f4f6", color: "#374151", fontSize: "0.82rem" }}>Cancelar</button>
          <button
            onClick={() => { onSave(form); onClose(); }}
            className="px-4 py-2 rounded-lg text-white"
            style={{ background: "#1E3A5F", fontSize: "0.82rem" }}
          >Guardar</button>
        </div>
      </div>
    </div>
  );
}

export function WorkersScreen() {
  const [workers, setWorkers] = useState(initialWorkers);
  const [search, setSearch] = useState("");
  const [areaFilter, setAreaFilter] = useState("Todas");
  const [modal, setModal] = useState<{ open: boolean; worker: (typeof initialWorkers)[0] | null }>({ open: false, worker: null });

  const filtered = workers.filter(w => {
    const matchSearch = w.name.toLowerCase().includes(search.toLowerCase()) || w.id.toLowerCase().includes(search.toLowerCase());
    const matchArea = areaFilter === "Todas" || w.area === areaFilter;
    return matchSearch && matchArea;
  });

  const statusColor = (s: string) =>
    s === "Activo" ? { bg: "rgba(46,139,87,0.1)", text: "#2E8B57" } :
    s === "Inactivo" ? { bg: "rgba(192,57,43,0.1)", text: "#c0392b" } :
    { bg: "rgba(230,126,34,0.1)", text: "#e67e22" };

  return (
    <div className="p-6 space-y-5 overflow-y-auto h-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <p style={{ color: "#6b7a8d", fontSize: "0.8rem" }}>{workers.length} trabajadores registrados</p>
        </div>
        <button
          onClick={() => setModal({ open: true, worker: null })}
          className="flex items-center gap-2 px-4 py-2 rounded-lg text-white"
          style={{ background: "linear-gradient(90deg, #1E3A5F, #243f6b)", fontSize: "0.82rem", fontWeight: 500 }}
        >
          <Plus className="w-4 h-4" /> Registrar Trabajador
        </button>
      </div>

      {/* Filters */}
      <div className="flex gap-3">
        <div className="relative flex-1 max-w-xs">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "#9ca3af" }} />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Buscar por nombre o código..."
            className="w-full pl-9 pr-4 py-2 rounded-lg border outline-none"
            style={{ borderColor: "#e5e7eb", background: "#fff", fontSize: "0.82rem", color: "#374151" }}
          />
        </div>
        <div className="relative">
          <Filter className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "#9ca3af" }} />
          <select
            value={areaFilter}
            onChange={e => setAreaFilter(e.target.value)}
            className="pl-8 pr-8 py-2 rounded-lg border outline-none appearance-none"
            style={{ borderColor: "#e5e7eb", background: "#fff", fontSize: "0.82rem", color: "#374151" }}
          >
            {["Todas","Incubación","Crianza","Engorde","Beneficio","Empaque","Almacén"].map(a => <option key={a}>{a}</option>)}
          </select>
          <ChevronDown className="w-3.5 h-3.5 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: "#9ca3af" }} />
        </div>
      </div>

      {/* Table */}
      <div className="rounded-xl shadow-sm overflow-hidden" style={{ background: "#fff", border: "1px solid rgba(30,58,95,0.08)" }}>
        <table className="w-full">
          <thead>
            <tr style={{ background: "#f8f9fb" }}>
              {["Código","Nombre","Área Asignada","Cargo","Estado","Acciones"].map(h => (
                <th key={h} className="px-5 py-3 text-left" style={{ color: "#6b7a8d", fontSize: "0.72rem", fontWeight: 600, letterSpacing: "0.05em" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((w, i) => {
              const sc = statusColor(w.status);
              return (
                <tr key={w.id} style={{ borderTop: "1px solid rgba(30,58,95,0.05)", background: i % 2 === 0 ? "#fff" : "#fafbfc" }}>
                  <td className="px-5 py-3" style={{ color: "#1E3A5F", fontSize: "0.78rem", fontWeight: 600 }}>{w.id}</td>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: "#1E3A5F" }}>
                        <span className="text-white" style={{ fontSize: "0.62rem", fontWeight: 700 }}>
                          {w.name.split(" ").slice(0,2).map(n => n[0]).join("")}
                        </span>
                      </div>
                      <span style={{ color: "#1a2332", fontSize: "0.82rem" }}>{w.name}</span>
                    </div>
                  </td>
                  <td className="px-5 py-3">
                    <span className="px-2.5 py-1 rounded-md" style={{ background: "rgba(30,58,95,0.07)", color: "#1E3A5F", fontSize: "0.75rem" }}>{w.area}</span>
                  </td>
                  <td className="px-5 py-3" style={{ color: "#374151", fontSize: "0.8rem" }}>{w.cargo}</td>
                  <td className="px-5 py-3">
                    <span className="px-2.5 py-1 rounded-full" style={{ background: sc.bg, color: sc.text, fontSize: "0.72rem", fontWeight: 600 }}>{w.status}</span>
                  </td>
                  <td className="px-5 py-3">
                    <div className="flex gap-2">
                      <button
                        onClick={() => setModal({ open: true, worker: w })}
                        className="p-1.5 rounded-lg transition-colors"
                        style={{ background: "rgba(30,58,95,0.07)", color: "#1E3A5F" }}
                      ><Edit2 className="w-3.5 h-3.5" /></button>
                      <button
                        onClick={() => setWorkers(prev => prev.filter(x => x.id !== w.id))}
                        className="p-1.5 rounded-lg transition-colors"
                        style={{ background: "rgba(192,57,43,0.07)", color: "#c0392b" }}
                      ><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div className="text-center py-10" style={{ color: "#6b7a8d", fontSize: "0.85rem" }}>
            No se encontraron trabajadores con los filtros aplicados.
          </div>
        )}
        <div className="px-5 py-3 flex items-center justify-between" style={{ borderTop: "1px solid rgba(30,58,95,0.07)" }}>
          <span style={{ color: "#6b7a8d", fontSize: "0.75rem" }}>Mostrando {filtered.length} de {workers.length} registros</span>
          <div className="flex gap-1">
            {[1, 2].map(p => (
              <button key={p} className="w-7 h-7 rounded flex items-center justify-center" style={{
                background: p === 1 ? "#1E3A5F" : "#f3f4f6",
                color: p === 1 ? "#fff" : "#374151",
                fontSize: "0.78rem"
              }}>{p}</button>
            ))}
          </div>
        </div>
      </div>

      {modal.open && (
        <WorkerModal
          worker={modal.worker}
          onClose={() => setModal({ open: false, worker: null })}
          onSave={(w) => {
            if (modal.worker) {
              setWorkers(prev => prev.map(x => x.id === w.id ? w : x));
            } else {
              setWorkers(prev => [...prev, w]);
            }
          }}
        />
      )}
    </div>
  );
}
